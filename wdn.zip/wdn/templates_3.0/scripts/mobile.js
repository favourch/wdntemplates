/**
 * This file is part of the UNL WDN templates.
 * @see http://wdn.unl.edu/
 * $Id$
 */
var _gaq=_gaq||[];
analytics=function(){return{initialize:function(){_gaq.push(["_setAccount","UA-3203435-1"],["_setDomainName",".unl.edu"],["_setAllowLinker",true],["_setAllowHash",false]);analytics.loadGA()},loadGA:function(){_gaq.push(["_trackPageview"]);(function(){var a=document.createElement("script");a.type="text/javascript";a.async=true;a.src=("https:"==document.location.protocol?"https://ssl":"http://www")+".google-analytics.com/ga.js";var b=document.getElementsByTagName("script")[0];b.parentNode.insertBefore(a,b)})()}}}();
analytics.initialize();
