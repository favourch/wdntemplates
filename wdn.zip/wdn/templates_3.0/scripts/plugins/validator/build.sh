java -jar ../../../build/compiler.jar --js=jquery.validator.js --js_output_file=jquery.validator.min.js
