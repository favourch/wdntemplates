tinyMCEPopup.requireLangPack();

var UnlTooltipDialog = {

	init : function() {
		var selection = tinyMCEPopup.editor.selection;
		var node = Unl.hasParentNodeWithClass(selection.getNode(), 'tooltip');
		
		if (node) {
			document.getElementById('unlTooltipText').value = node.title;
		}
	
		document.getElementById('unlTooltipForm').onsubmit = UnlTooltipDialog.submit;
	},

	submit : function() {
		var selection = tinyMCEPopup.editor.selection;
		var node = Unl.hasParentNodeWithClass(selection.getNode(), 'tooltip');
		var newTitle = document.getElementById('unlTooltipText').value;
		
		if (node) {
			node.title = newTitle;
		} else {
			selection.setContent('<a class="tooltip" href="#" title="' + newTitle + '">' + selection.getContent() + '</a>');
		}
		
		tinyMCEPopup.close();
		return false;
	}
};

tinyMCEPopup.onInit.add(UnlTooltipDialog.init, UnlTooltipDialog);
